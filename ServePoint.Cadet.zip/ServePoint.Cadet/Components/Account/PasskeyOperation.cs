namespace ServePoint.Cadet.Components.Account;

public enum PasskeyOperation
{
    Create = 0,
    Request = 1,
}
