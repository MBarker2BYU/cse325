﻿namespace ServePoint.Cadet.Models.Opportunities;

public sealed class CreateModel : CreateEditModelBase
{}